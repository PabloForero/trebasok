/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trebas_Asignment;

import java.util.Scanner;

/**
 *
 * @author pablo
 */
public class Exercise_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter loan: ");
        double loan = sc.nextDouble();
        System.out.print("Please enter rate of interest: ");
        double rate = sc.nextDouble();
        System.out.print("Please enter time(years): ");
        double time = sc.nextDouble();
        double sInterest = (loan * rate * time) / 100;
        double cInterest = loan * Math.pow((1 + rate/100), time) - loan;

        System.out.printf("The simple Interest is: %.2f\n", sInterest);
        System.out.printf("The compound Interest is: %.2f\n", cInterest);
    }
}
