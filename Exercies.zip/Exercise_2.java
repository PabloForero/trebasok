/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trebas_Asignment;

/**
 *
 * @author pablo
 */
public class Exercise_2 {
    private double aToc; // length of hypotenuse
    
    public Exercise_2(double ac) {
        this.aToc = aToc;
    }
    
    public double calculateDistanceAToB(double bToc) {
        double aTob = Math.sqrt(Math.pow(aToc, 2) - Math.pow(bToc, 2));
        return aTob;
    }
    
    public double calculateTime(double distance) {
        double walkingSpeed = 10;
        double time = distance / walkingSpeed;
        return time;
    }
    
    public static void main(String[] args) {
        Exercise_2 triangle = new Exercise_2(97);
        double bToc = 72;
        double distanceAToB = triangle.calculateDistanceAToB(bToc);
        double timeUsed = triangle.calculateTime(distanceAToB);
        System.out.println("The distance from point A to point B is: " + distanceAToB + "m");
        System.out.println("The time used to travel from point A to point B is: " + timeUsed + " hours");
    }
}
