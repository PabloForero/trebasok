/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trebas_Asignment;

/**
 *
 * @author pablo
 */
public class Exercise_3 {
    public static double calcytm(double c, double f, double p, double n) {
        return (c + (f - p) / n) / ((f + p) / 2);
    }

    public static void main(String[] args) {
        double c = 100;
        double f = 1000;
        double p = 900;
        double n = 5;

        double ytm = calcytm(c, f, p, n);
        System.out.printf("The yield to maturity is: %.2f%%\n", ytm * 100);
    }
}
