/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trebas_Asignment;

import java.util.Scanner;

/**
 *
 * @author pablo
 */

class Transport {
    int fuelCapacity;
    
    Transport(int fuelCapacity) {
        this.fuelCapacity = fuelCapacity;
    }
    
    double getMileage(int distance) {
        return distance / fuelCapacity;
    }
}

class Car extends Transport {
    int distance;
    double fuelPrice;
    
    Car(int fuelCapacity, int distance, double fuelPrice) {
        super(fuelCapacity);
        this.distance = distance;
        this.fuelPrice = fuelPrice;
    }
    
    double getMileage() {
        return super.getMileage(distance);
    }
    
    double getCost() {
        return fuelPrice * fuelCapacity;
    }
    
    double getCostPerKm() {
        return fuelPrice / getMileage();
    }
}

public class Exercise_1 {
    public static void main(String[] args) {
        int fuel, distance, price;
         Scanner input = new Scanner(System.in);

        System.out.print("Please enter the fuel capacity (L): ");
        fuel = input.nextInt();
        System.out.print("Please enter the distance travelled(KM): ");
        distance = input.nextInt();
        System.out.print("Please enter the gas price($): ");
        price = input.nextInt();
        Car myCar = new Car(fuel, distance, price);
        double mileage = myCar.getMileage();
        double cost = myCar.getCost();
        double costPerKm = myCar.getCostPerKm();
        System.out.println("The mileage of my car is: " + mileage + " km/litre");
        System.out.println("The cost to fill the tank is: $" + cost);
        System.out.println("The cost per km travelled is: $" + costPerKm);
    }
}